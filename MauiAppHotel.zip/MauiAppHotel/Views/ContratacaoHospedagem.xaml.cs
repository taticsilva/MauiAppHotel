

namespace MauiAppHotel.Views;

public partial class ContratacaoHospedagem : ContentPage
{
    public ContratacaoHospedagem()
    {
        InitializeComponent();
    }

    private async void OnSobreClicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new SobrePage());
    }

    private async void OnAvancarClicked(object sender, EventArgs e)
    {
        if (pickerAcomodacaoTela.SelectedIndex == -1)
        {
            await DisplayAlert("Atenção", "Selecione uma acomodação.", "OK");
            return;
        }

        if (stepperAdultosTela.Value + stepperCriancasTela.Value == 0)
        {
            await DisplayAlert("Atenção", "Informe a quantidade de hóspedes.", "OK");
            return;
        }

        if (dataCheckoutTela.Date <= dataCheckinTela.Date)
        {
            await DisplayAlert("Atenção", "O check-out deve ser posterior ao check-in.", "OK");
            return;
        }

        await Navigation.PushAsync(new HospedagemContratada());
    }
}
