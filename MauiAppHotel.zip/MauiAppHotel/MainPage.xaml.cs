﻿
namespace MauiAppHotel
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnQuantidadeChanged(object sender, ValueChangedEventArgs e)
        {
            QuantidadeLabel.Text = $"{(int)e.NewValue} hóspede(s)";
        }

        private async void OnReservarClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NomeEntry.Text))
            {
                await DisplayAlert("Atenção", "Digite o nome do hóspede.", "OK");
                return;
            }

            if (TipoQuarto.SelectedIndex == -1)
            {
                await DisplayAlert("Atenção", "Selecione uma acomodação.", "OK");
                return;
            }

            if (DataSaida.Date <= DataEntrada.Date)
            {
                await DisplayAlert("Atenção", "A saída deve ser posterior à entrada.", "OK");
                return;
            }

            await DisplayAlert(
                "Reserva",
                $"Hóspede: {NomeEntry.Text}\n" +
                $"Entrada: {DataEntrada.Date:dd/MM/yyyy}\n" +
                $"Saída: {DataSaida.Date:dd/MM/yyyy}\n" +
                $"Acomodação: {TipoQuarto.SelectedItem}\n" +
                $"Hóspedes: {(int)Quantidade.Value}",
                "OK");
        }

        private async void OnSobreClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Views.SobrePage());
        }
    }
}
